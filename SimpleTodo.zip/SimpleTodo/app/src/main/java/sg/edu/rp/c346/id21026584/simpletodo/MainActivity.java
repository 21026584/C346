package sg.edu.rp.c346.id21026584.simpletodo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
Button btnAddTask;
Button btnDeleteTask;
Button btnClearList;
ListView lvTasks;
EditText etTask;
Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnAddTask = findViewById(R.id.buttonAddTask);
        btnClearList = findViewById(R.id.buttonClearList);
        btnDeleteTask = findViewById(R.id.buttonDeleteTask);
        lvTasks = findViewById(R.id.ListViewTask);
        etTask = findViewById(R.id.editTextTask);
        spinner = findViewById(R.id.spinner);

        ArrayList<String> TaskList = new ArrayList<>();
        ArrayAdapter ListOfTask = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, TaskList);
        lvTasks.setAdapter(ListOfTask);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                switch (position) {
                    case 0:
                        etTask.setText("Type in a new Task here");
                        btnAddTask.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                String Task = etTask.getText().toString();
                                TaskList.add(Task);
                                ListOfTask.notifyDataSetChanged();
                            }
                        });

                        btnClearList.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                TaskList.clear();
                                ListOfTask.notifyDataSetChanged();
                            }
                        });

                    case 1:
                        etTask.setText("Type in the index of the task to be removed");
                        btnDeleteTask.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                int taskid = Integer.parseInt(etTask.getText().toString());
                                TaskList.remove(taskid - 1);
                                ListOfTask.notifyDataSetChanged();
                            }
                        });
                }

                        btnClearList.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                TaskList.clear();
                                ListOfTask.notifyDataSetChanged();
                            }
                        });
                }


            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }

        });





    }
}