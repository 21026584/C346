package sg.edu.rp.c346.id21026584.carparkapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.AdapterView;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import cz.msebera.android.httpclient.*;

public class MainActivity extends AppCompatActivity {

    ListView lvCarPark;
    AsyncHttpClient client;
    ArrayAdapter<CarPark> aaCarpark;
    ArrayList<CarPark> alCarpark;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lvCarPark = findViewById(R.id.lvCarPark);
        client = new AsyncHttpClient();
        alCarpark = new ArrayList<CarPark>();
    }

    @Override
    protected void onResume() {
        super.onResume();
        client.get("https://api.data.gov.sg/v1/transport/carpark-availability", new JsonHttpResponseHandler() {

            String lot_type;
            String carpark_number;
            int total_lots;
            int lots_available;

            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                try {

                    JSONArray jsonArrData = response.getJSONArray ("carpark_data");
                    JSONArray jsonArrInfo = jsonArrData.getJSONArray(0);
                    for (int i = 0; i < jsonArrInfo.length(); i++) {
                        JSONObject jsonObjData = jsonArrInfo.getJSONObject(i);
                        total_lots = jsonObjData.getInt("total_lots");
                        lot_type = jsonObjData.getString("lot_type");
                        lots_available = jsonObjData.getInt("lots_available");
                        carpark_number = jsonObjData.getString("carpark_number");
                        CarPark carpark = new CarPark(total_lots, lot_type, carpark_number, lots_available);
                        alCarpark.add(carpark);
                    }
                } catch (JSONException e) {

                }

                aaCarpark = new ArrayAdapter<CarPark>(MainActivity.this,
                        R.layout.activity_main, alCarpark);
                lvCarPark.setAdapter(aaCarpark);


            }
        });
    }
}