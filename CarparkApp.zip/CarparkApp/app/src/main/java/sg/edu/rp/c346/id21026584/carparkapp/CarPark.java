package sg.edu.rp.c346.id21026584.carparkapp;

import java.io.Serializable;

public class CarPark{

    private int totalLots;
    private String lot_type;
    private String number;
    private int availableLots;

    public CarPark(int totalLots, String lot_type, String number, int availableLots) {
        this.totalLots = totalLots;
        this.lot_type = lot_type;
        this.number = number;
        this.availableLots = availableLots;
    }

    public int getTotalLots() {
        return totalLots;
    }

    public void setTotalLots(int totalLots) {
        this.totalLots = totalLots;
    }

    public String getType() {
        return lot_type;
    }

    public void setType(String type) {
        this.lot_type = type;
    }

    public String getNumber() {
    return number;
    }

    public void setNumber(String number) {
      this.number = number;
    }

    public int getAvailableLots() {
        return availableLots;
    }

    public void setAvailableLot(int availableLots) {
        this.availableLots = availableLots;
    }


    public String toString() {
        return "Car park" + "\n Number: "+ number
                +"\n Type:" + lot_type
                +"\n Total  lots:" + totalLots
                +"\n Available lots:" + availableLots;
    }
}
