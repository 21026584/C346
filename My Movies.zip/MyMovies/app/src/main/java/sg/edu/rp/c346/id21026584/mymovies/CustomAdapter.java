package sg.edu.rp.c346.id21026584.mymovies;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

public class CustomAdapter extends ArrayAdapter {

    Context parent_context;
    int layout_id;
    ArrayList<Movies> List;

    public CustomAdapter(Context context, int resource,
                         ArrayList<Movies> objects) {
        super(context, resource, objects);

        parent_context = context;
        layout_id = resource;
        List = objects;

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Obtain the LayoutInflater object
        LayoutInflater inflater = (LayoutInflater)
                parent_context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(layout_id, parent, false);

        TextView tvTitle = rowView.findViewById(R.id.tvTitle);
        TextView tvGenre = rowView.findViewById(R.id.tvGenre);
        TextView tvYear = rowView.findViewById(R.id.tvYear);
        ImageView Rating = rowView.findViewById(R.id.Rating);
        Movies item = List.get(position);
        tvTitle.setText(item.getTitle());
        tvGenre.setText(item.getGenre());
        tvYear.setText(String.valueOf(item.getYear()));


        if (item.getRating() == "G") {
            Rating.setImageResource(R.drawable.rating_g);
        } else if (item.getRating() == "PG") {
            Rating.setImageResource(R.drawable.rating_pg);
        } else if(item.getRating() == "PG13") {
            Rating.setImageResource(R.drawable.rating_pg13);
        } else if(item.getRating() == "R21"){
            Rating.setImageResource(R.drawable.rating_r21);
        }
        else if(item.getRating() == "NC16") {
            Rating.setImageResource(R.drawable.rating_nc16);

        }else if(item.getRating() == "NC16"){
            Rating.setImageResource(R.drawable.rating_m18);
        }
        return rowView;
    }
}