package sg.edu.rp.c346.id21026584.mymovies;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Spinner;

import androidx.media2.common.Rating;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "myMovies.db";
    private static final int DATABASE_VERSION = 2;
    private static final String TABLE_MOVIES = "Movies";
    private static final String COLUMN_ID = "_id";
    private static final String COLUMN_TITLE = "title";
    private static final String COLUMN_YEAR = "year";
    private static final String COLUMN_GENRE = "genre";
    private static final String COLUMN_RATING = "rating";


    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_MOVIE_SQL = "CREATE TABLE " + TABLE_MOVIES  + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_TITLE + " TEXT," + COLUMN_GENRE + " TEXT," + COLUMN_YEAR + " INTEGER,"+ COLUMN_RATING + " TEXT" + ")";
        db.execSQL(CREATE_MOVIE_SQL);
        Log.i("info", "created tables");

        //Dummy records, to be inserted when the database is created
        for (int i = 0; i< 4; i++) {
            ContentValues values = new ContentValues();
            values.put(COLUMN_ID + COLUMN_TITLE + COLUMN_YEAR + COLUMN_GENRE + COLUMN_RATING,"Data number " + i);
            db.insert(TABLE_MOVIES , null, values);
        }
        Log.i("info", "dummy records inserted");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //db.execSQL("DROP TABLE IF EXISTS " + TABLE_NOTE);
        db.execSQL("ALTER TABLE " + TABLE_MOVIES  + " ADD COLUMN  module_name TEXT ");
        //onCreate(db);
    }

    public long insertMovies(String Title,  String Genre, int Year, String Rating) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, Title);
        values.put(COLUMN_GENRE, Genre);
        values.put(COLUMN_YEAR, Year);
        values.put(COLUMN_RATING, Rating);
        long result = db.insert(TABLE_MOVIES, null, values);
        db.close();
        Log.d("SQL Insert","ID:"+ result); //id returned, shouldn’t be -1
        return result;
    }

    public ArrayList<Movies> getAllMovies() {
        ArrayList<Movies> movies = new ArrayList<Movies>();

        SQLiteDatabase db = this.getReadableDatabase();

        String[] columns= {COLUMN_ID, COLUMN_TITLE, COLUMN_GENRE,COLUMN_YEAR, COLUMN_RATING};
        Cursor cursor = db.query(TABLE_MOVIES , columns, null,null, null,
                null, null, null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String title = cursor.getString(1);
                String genre = cursor.getString(2);
                String rating = cursor.getString(4);
                int year = cursor.getInt(3);
                Movies song = new Movies(id,title,year,genre,rating);
                movies.add(song);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return movies;
    }
    public int updateMovies(Movies data){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE+COLUMN_YEAR+COLUMN_GENRE+COLUMN_RATING, data.getMoviesContent());
        String condition = COLUMN_ID + "= ?";
        String[] args = {String.valueOf(data.getId())};
        int result = db.update(TABLE_MOVIES , values, condition, args);
        db.close();
        return result;
    }
    public int deleteMovies(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        String condition = COLUMN_ID + "= ?";
        String[] args = {String.valueOf(id)};
        int result = db.delete(TABLE_MOVIES , condition, args);
        db.close();
        return result;
    }





}
