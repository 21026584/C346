package sg.edu.rp.c346.id21026584.mymovies;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ListActivity extends AppCompatActivity {

    ListView lv;
    Button btnShowPG13;
    ArrayList<Movies> alMovies;
    ArrayAdapter<Movies> aa;
    CustomAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        lv = findViewById(R.id.lv);
        btnShowPG13 = findViewById(R.id.btnShowPG13);
        alMovies = new ArrayList<Movies>();
        ArrayList<String> str = new ArrayList<String>();
        //aa = new ArrayAdapter<Song>(this,
        //android.R.layout.simple_list_item_1, al);
        DBHelper db = new DBHelper(ListActivity.this);
        alMovies = db.getAllMovies();
        adapter = new CustomAdapter(this, R.layout.row, alMovies);
        lv.setAdapter(adapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long identity) {
                Movies data = alMovies.get(position);
                Intent i = new Intent(ListActivity.this,EditActivity.class);
                i.putExtra("data",data);
                startActivity(i);

            }
        });

        btnShowPG13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DBHelper dbh = new DBHelper(ListActivity.this);

            }
        });
    }

}
