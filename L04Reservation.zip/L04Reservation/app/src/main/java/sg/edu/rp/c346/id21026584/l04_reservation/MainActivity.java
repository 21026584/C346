package sg.edu.rp.c346.id21026584.l04_reservation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.ToggleButton;



public class MainActivity extends AppCompatActivity {
    DatePicker dp;
    TimePicker tp;
    ToggleButton  tbSmoking;
    ToggleButton tbNonSmoking;
    TextView tvDisplay1;
    TextView tvDisplay2;
    TextView tvDisplay3;
    Button   btnConfirm;
    Button   btnReset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dp = findViewById(R.id.datePicker);
        tp = findViewById(R.id.timePicker);
        tbSmoking = findViewById(R.id.tbSmokingArea);
        tbNonSmoking = findViewById(R.id.tbNonSmokingArea);
        tvDisplay1 = findViewById(R.id.textViewDetails);
        tvDisplay2 = findViewById(R.id.textViewDetails2);
        tvDisplay3 = findViewById(R.id.textViewDetails3);
        btnConfirm = findViewById(R.id.buttonConfirm);
        btnReset = findViewById(R.id.buttonReset);

        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View text) {
                if (tbSmoking.isChecked()) {
                    tvDisplay1.setText("Reservation Time " + tp.getCurrentHour().toString() + ":" + tp.getCurrentMinute().toString());
                    tvDisplay2.setText("Reservation Date " + dp.getDayOfMonth() + "/" + dp.getMonth() + "/" + dp.getYear());
                    tvDisplay3.setText("Choosen area: Smoking area");
                }else{
                    tvDisplay1.setText("Reservation Time " + tp.getCurrentHour().toString() + ":" + tp.getCurrentMinute().toString());
                    tvDisplay2.setText("Reservation Date " + dp.getDayOfMonth() + "/" + dp.getMonth() + "/" + dp.getYear());
                    tvDisplay3.setText("Choosen area: Non-smoking area");
                }
            }
        });

        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View text) {
                tp.setCurrentHour(19);
                tp.setCurrentMinute(30);
                dp.updateDate(2022,06,01);
            }
        });



    }
}