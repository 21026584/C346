package sg.edu.rp.c346.id21026584.mymodules;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ModuleDetails extends AppCompatActivity {
TextView Name;
TextView Sem;
TextView Credit;
TextView Year;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_module_details);
        Name = findViewById(R.id.Name);
        Year = findViewById(R.id.Year);
        Sem = findViewById(R.id.Sem);
        Credit = findViewById(R.id.Credit);

      Intent intentReceived = getIntent();
      String ChosenModule = intentReceived.getStringExtra("module");

      if (ChosenModule.equals("C346")){
            Name.setText("Name: Android Programming");
            Sem.setText("Semester 2");
            Credit.setText("Modular Credits: 4");
            Year.setText("Academic Year 2022");
      }

        if (ChosenModule.equals("C203")){
            Name.setText("Name: Web App Development in PHP");
            Sem.setText("Semester 2");
            Credit.setText("Modular Credits: 4");
            Year.setText("Academic Year 2022");
        }

        if (ChosenModule.equals("C235")){
            Name.setText("Name: IT Security And Management");
            Sem.setText("Semester 2");
            Credit.setText("Modular Credits: 4");
            Year.setText("Academic Year 2022");
        }

        if (ChosenModule.equals("C218")){
            Name.setText("Name: UI/UX Design");
            Sem.setText("Semester 2");
            Credit.setText("Modular Credits: 4");
            Year.setText("Academic Year 2022");
        }

        if (ChosenModule.equals("C206")){
            Name.setText("Name: Software Development Process");
            Sem.setText("Semester 2");
            Credit.setText("Modular Credits: 4");
            Year.setText("Academic Year 2022");
        }
    }
}