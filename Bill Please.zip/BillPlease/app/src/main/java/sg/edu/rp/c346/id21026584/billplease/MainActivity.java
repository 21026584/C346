package sg.edu.rp.c346.id21026584.billplease;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
TextView tv;
TextView tv2;
ToggleButton tb;
ToggleButton gstTb;
RadioButton cashRb;
RadioButton paynowRb;
ToggleButton resetTb;
EditText et;
RadioGroup rg;
Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = findViewById(R.id.Message);
         tv2 = findViewById(R.id.Message2);
         gstTb = findViewById(R.id.gst);
         cashRb =findViewById(R.id.cash);
         paynowRb = findViewById(R.id.paynow);
         resetTb = findViewById(R.id.reset);
        int totalamount = Integer.parseInt(String.valueOf(findViewById(R.id.amount))) *
                Integer.parseInt(String.valueOf(findViewById(R.id.amountofpeople)));
       int SplittedUpCost = totalamount/Integer.parseInt(String.valueOf(findViewById(R.id.amountofpeople)));

        tb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View text) {
                int extracharge = 0;
                if(gstTb.isChecked()){
                   extracharge = totalamount * (7/100) ;
                }
                else{
                    extracharge = totalamount * (10/100);
                }
            }
        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                et.getText().toString();
                String stringResponse = et.getText().toString();
                int checkedOption = rg.getCheckedRadioButtonId();
                if(checkedOption == R.id.paynow){
                    tv2.setText("Each Pay:" + SplittedUpCost + " via PayNow to 912345678");
                }
                else{
                    tv2.setText("Each Pay:" + SplittedUpCost + " in Cash");
                }
            }
        });

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(resetTb.isChecked()){
                   cashRb.setChecked(false);
                   paynowRb.setChecked(false);

                }
              else{
                  tv.setText("Total Bill:" + totalamount);
                }
            }
        });
    }
}