package sg.edu.rp.c346.id21026584.p09_ps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onResume() {
        super.onResume();

        btnShowList.performClick();
    }

    Button btnInsert;
    Button btnShowList;
    RadioGroup rgRating;
    EditText etTitle;
    EditText etYear;
    EditText etSinger;
    ArrayList<Song> al;
    ArrayAdapter<Song> aa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etSinger = findViewById(R.id.etSinger);
        etYear = findViewById(R.id.etYear);
        rgRating = findViewById(R.id.rgRating);
        btnInsert = findViewById(R.id.btnInsert);
        btnShowList = findViewById(R.id.btnShowList);
        al = new ArrayList<Song>();
        aa = new ArrayAdapter<Song>(this,
                android.R.layout.simple_list_item_1, al);

        //initialize the variables with UI here
        rgRating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int checkedOption = rgRating.getCheckedRadioButtonId();
                if(checkedOption == R.id.rgb1){
                  rgRating.equals(1);
                }

                else if(checkedOption == R.id.rgb2){
                    rgRating.equals(2);
                }
                else if(checkedOption == R.id.rgb3){
                    rgRating.equals(3);
                }
               else if(checkedOption == R.id.rgb4){
                    rgRating.equals(3);
                }
               else if(checkedOption == R.id.rgb5){
                    rgRating.equals(3);
                }
            }
        });

        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data = etTitle.getText().toString();
                DBHelper dbh = new DBHelper(MainActivity.this);
                long inserted_id = dbh.insertSong(data);

                if (inserted_id != -1) {
                    al.clear();
                    al.addAll(dbh.getAllSong());
                    aa.notifyDataSetChanged();
                    Toast.makeText(MainActivity.this, "Insert successful",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
        btnShowList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent I = new Intent(MainActivity.this, ListActivity.class);

                startActivity(I);
            }
        });


    }
}
