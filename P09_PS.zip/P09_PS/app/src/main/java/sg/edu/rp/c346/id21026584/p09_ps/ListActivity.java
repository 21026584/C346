package sg.edu.rp.c346.id21026584.p09_ps;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;


public class ListActivity extends AppCompatActivity {
    ListView lv;
    ArrayList<Song> al;
    ArrayAdapter<Song> aa;
    Intent intent = getIntent();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);


        lv = findViewById(R.id.lv);
        al = new ArrayList<Song>();
        aa = new ArrayAdapter<Song>(this,
                android.R.layout.simple_list_item_1, al);

        lv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DBHelper dbh = new DBHelper(ListActivity.this);
                al.clear();
                int listsize = al.size();
                ArrayList<Song> list = dbh.getAllSong();

                for (int i = 0; i < listsize; i++)
                {
                    Song song =list.get(i);
                    al.add(song);

                }

                lv.setAdapter(aa);
                
                aa.notifyDataSetChanged();
            }
        });

    }
    }

